console.log("Hello!");

// DOM Elements
const productGrid = document.getElementById("productGrid");
const productCount = document.getElementById("productCount");

const searchInput = document.getElementById("searchInput");
const searchBtn = document.getElementById("searchBtn");

const catergoryList = document.getElementById("categoryList");

const minPriceInput = document.getElementById("minPrice");
const maxPriceInput = document.getElementById("maxPrice");


const filterBtn = document.querySelector(".filter-btn");

const sortSelect = document.getElementById("sortSection");

const pagination = document.getElementById("pagination");

const cartCount = document.querySelector(".cart-count");


// Applications State
let currentPage = 1;
let limit = 21;
let totalProducts = 0;
let currentSearch = "";
let currentCategory = "";
let currentSort = "";

let minPrice = null;
let maxPrice = null;


let cart = [];

const API_URL = "https://dummyjson.com/products";


// Fetch Actual Products

async function fetchProdcts() {
    try {

        showLoding();

        // Calculate URL

        // 1, 2, 3 ....................100
        // curr = 1, limit 6 => 1 to 6     skip = 0
        // curr = 2 => 6 to 12    skip = 6
        //skip = 12  
        const skip = (currentPage - 1) * limit;

        let url;

        if (currentSearch) {
            url = `${API_URL}/search?q=${currentSearch}&limit=${limit}&skip=${skip}`;
        } else if (currentCategory) {
            url = `${API_URL}/category/${currentCategory}?limit=${limit}&skip=${skip}`;
        } else {
            url = `${API_URL}?limit=${limit}&skip=${skip}`;
        }

        // Add sorting

        if (currentSort == "price-low") {
            url += "&sortBy=price&order=asc"
        } else if (currentSort == "price-high") {
            url += "&sortBy=price&order=desc"
        } else if (currentSort == "rating") {
            url += "&sortBy=rating&order=asc"
        }

        console.log("FINAL URL", url);


        // Call the api

        const response = await fetch(url);

        if (!response.ok) {
            throw new Error("Failed to fetch products");
        }


        let data = await response.json();
        console.log("response", data);

        totalProducts = data.total;

        let products = data.products;

        if (minPrice !== null) {
            products = products.filter((prodcut) => prodcut.price >= minPrice);
        }
        if (maxPrice !== null) {
            products = products.filter((prodcut) => prodcut.price <= maxPrice);
        }


        //Render

        displayProducts(products);

        renderPagination();

        updateProductCounts(products.length);


    } catch (error) {
        console.error(error);
    }

}

// display

function displayProducts(products) {
    productGrid.innerHTML = "";

    if (products.length === 0) {
        productGrid.innerHTML = `
        <div class="no-products">
            <h3>No products found</h3>
            <p>Try changing the filters!</p>
        </div>
    `;
    }

    products.forEach(product => {

        // discountPercentage
        // price
        //oldPice 
        // price = oldPrice * (1 - discountPercentage/100)

        // 100, 10%, 90
        // 100 - ((10/100) * 100)
        // x, r, n
        // n = x - ((r/100) * x)
        // n = x (1 - r / 100)

        let originalPrice = product.price / (1 - product.discountPercentage / 100);

        originalPrice = financial(originalPrice);
        

        // starts
        const stars = generateStars(product.rating);

        // Create html and render it

        const productCard = `
                <article class="product-card">
                    <div class="product-image">
                        <img src="${product.thumbnail}"
                            alt="${product.title}">

                        <span class="discount">
                           ${product.discountPercentage}%
                        </span>
                    </div>
                    <div class="product-info">
                        <span class="product-category">
                            ${product.category}
                        </span>

                        <h3>${product.title}</h3>

                        <div class="rating">
                            ${stars}
                            <span>${product.rating}</span>
                        </div>

                        <div class="price-row">
                            <strong>
                                $${product.price}
                            </strong>

                            <span class="old-price">
                                $${originalPrice}
                            </span>
                        </div>

                        <button class="add-cart" onclick="addToCart(${product.id})">
                            Add to Cart
                        </button>
                    </div>
                </article>
                `;

        productGrid.innerHTML += productCard;
    });

}

function financial(x) {
  return Number.parseFloat(x).toFixed(2);
}

// stars

function generateStars(rating) {

    let stars = "";

    const roundedRating = Math.round(rating);

    for (let index = 1; index <= 5; index++) {
        if (index <= roundedRating) {
            stars += "★";
        } else {
            stars += "☆";
        }
    }

    return stars;
}

// product count 
function updateProductCounts(displayProducts) {
    if (totalProducts == 0) {
        productCount.textContent = "No products";
        return;
    }

    const start = (currentPage - 1) * limit + 1;
    const end = Math.min(totalProducts, start + displayProducts - 1)

    productCount.innerHTML = ` Showing ${start} - ${end} of ${totalProducts} products`;
}

//pagination
function renderPagination() {

    pagination.innerHTML = "";

    const totalPages = Math.ceil(totalProducts / limit);

    console.log("Total COunt", totalPages);


    const prevButton = document.createElement("button");
    prevButton.textContent = "← Previous";
    prevButton.className = "page-btn";
    prevButton.disabled = currentPage == 1;
    prevButton.addEventListener("click", () => {

        if (currentPage > 1) {

            currentPage--;

            fetchProdcts();

            // scrollToProduct();
        }
    });

    pagination.appendChild(prevButton);


    for (let page = 1; page <= totalPages; page++) {
        const pageButton = document.createElement("button");
        pageButton.textContent = page;
        pageButton.className = "page-number";
        if (page == currentPage) {
            pageButton.classList.add("active");
        }


        pageButton.addEventListener("click", () => {
            currentPage = page;

            fetchProdcts();

            // scrollToProduct();
        });

        pagination.appendChild(pageButton);

    }

    const nextButton = document.createElement("button");
    nextButton.textContent = "Next →";
    nextButton.className = "page-btn";
    nextButton.disabled = currentPage == totalPages;
    nextButton.addEventListener("click", () => {

        if (currentPage < totalPages) {

            currentPage++;

            fetchProdcts();

            // scrollToProduct();
        }
    });

    pagination.appendChild(nextButton);

}

// Search Btn Click
searchBtn.addEventListener("click", () => {

    currentSearch = searchInput.value.trim();

    currentCategory = "";

    currentPage = 1;

    fetchProdcts();

})

// Search using enter key

searchInput.addEventListener("keydown", (event) => {

    if (event.key === "Enter") {

        currentSearch = searchInput.value.trim();

        currentCategory = "";

        currentPage = 1;

        fetchProdcts();

    }
});


// Fetch Categories


async function fetchCategories() {
    try {
        const response = await fetch(`${API_URL}/categories`);

        const categories = await response.json();

        displayCategories(categories);

    } catch (error) {
        console.log("Failed to load categories", error);

    }
}

// display categories

function displayCategories(categories) {
    catergoryList.innerHTML = "";

    const allProductsItem = document.createElement("li");

    allProductsItem.innerHTML = `
    <li>
        <button class="category active">
            All Prodcuts
        </button>
    </li>
    `

    catergoryList.appendChild(allProductsItem);


    categories.forEach((category) => {

        const li = document.createElement("li");

        li.innerHTML = `
            <li>
                <button class="category" data-category="${category.slug}">
                    ${category.name}
                </button>
            </li>
        `

        catergoryList.appendChild(li);
    })

}


// category on click

catergoryList.addEventListener("click", (event) => {

    if (event.target.classList.contains("category")) {

        // remove active from full list

        const catergoryButtons = document.querySelectorAll(".category");

        catergoryButtons.forEach((button) => {
            button.classList.remove("active");
        });


        // Add active to selected category
        event.target.classList.add("active");

        currentCategory = event.target.dataset.category;

        currentSearch = "";
        searchInput.value = "";

        currentPage = 1;

        fetchProdcts();
    }

});

// Sorting
sortSelect.addEventListener("change", () => {
    currentSort = sortSelect.value;

    currentPage = 1;

    fetchProdcts();
})

// min price and max price filter

filterBtn.addEventListener("click", () => {


    const minValue = minPriceInput.value;
    const maxValue = maxPriceInput.value;

    minPrice = minValue === "" ? null : Number(minValue);

    // if(minValue === ""){
    //     minPrice = null
    // }else{
    //     minPrice = Number(minValue);
    // }

    maxPrice = maxValue === "" ? null : Number(maxValue);

    currentPage = 1;

    fetchProdcts();

})

// Add Cart

async function addToCart(productId) {

    try {


        const response = await fetch(`${API_URL}/${productId}`);
        const product = await response.json();

        // check if product already exists
        const existingProduct = cart.find((item) => {
            return item.id === product.id;
        })


        if(existingProduct){
            existingProduct.quantity++;
        }else{
            cart.push({
                id: product.id,
                title: product.title,
                price: product.price,
                thumbnail: product.thumbnail,
                quantity: 1
            })
        }

        updateCartCount();

        console.log(cart);
        

    } catch (error) {
        console.log("Unable to add item in cart", error);
    }

}

function updateCartCount(params) {
    let totalItems = 0;

    cart.forEach((item) => {
        totalItems += item.quantity;
    })

    cartCount.textContent = totalItems;
}


// Loading

function showLoding() {

    productGrid.innerHTML = `
        <div class="loading">
            Loading Products ...
        </div>
    `;

}





























async function initilizeAppp() {

    await fetchCategories();

    await fetchProdcts();
}

initilizeAppp();